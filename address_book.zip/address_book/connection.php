
<?php
$con = mysqli_connect("localhost","root","","address_book");
if($con){
    echo "Your connection fine";
}else{
    echo " Your connection is not fine";
}
if(isset($_POST["submit"])){
    $fname    = $_POST["firstName"];
    $lname    = $_POST["lastName"];
    $number   = $_POST["m_number"];
    $company  = $_POST["company"];
    $street   = $_POST["streetaddress"];
    $city     = $_POST["city"];
    $province = $_POST["province"];
    $country  = $_POST["country"];

   $msql = "INSERT INTO addressbook(fname,lname,mob_number,company,street,city,province,country) VALUES    ('$fname','$lname','$number','$company','$street','$city','$province','$country')";

    $query = mysqli_query($con,$msql);
    
    if($query){
        echo "<br>Your Data is Inserted successfully";
    }else{
        echo "<br>Your Data is not inserted successflly";
    }


}


?>
