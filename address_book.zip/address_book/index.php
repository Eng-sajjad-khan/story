

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="files/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h2 class="font-weight-bold text-center">Address Book</h2>

        <form action="connection.php" method="POST" class="w-50 offset-sm-3">

            <div class="form-group">
                <label for="" class="font-weight-bold">First Name :</label>
                <input type="text" name="firstName" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="" class="font-weight-bold">Last Name :</label>
                <input type="text" name="lastName" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="" class="font-weight-bold">Mobile No :</label>
                <input type="number" name="m_number" value="" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="" class="font-weight-bold">Company :</label>
                <input type="text" name="company" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="" class="font-weight-bold">Street/Address :</label>
                <input type="text" name="streetaddress" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="" class="font-weight-bold">City :</label>
                <input type="text" name="city" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="" class="font-weight-bold">State/Province :</label>
                <select name="province" class="form-control" required>
                    <option value="" selected>Open the select Menue</option>
                    <option value="Khyber phukhtoon khawa">Khyber phukhtoon khawa</option>
                    <option value="Sind">Sind</option>
                    <option value="Balochistan">Balochistan</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Gilgit baltistan">Gilgit baltistan</option>
                </select>
            </div>
            <div class="form-group">
                <label for="" class="font-weight-bold">Country :</label>
                <select name="country" class="form-control" required>
                    <option selected>Open the select Menue</option>
                    <option >Pakistan</option>
                    <option >China</option>
                    <option >America</option>
                    <option >Australia</option>
                    <option >Dubai</option>
                    <option >Suadi Arabia</option>
                    <option >Germany</option>
                    <option >Aghanistan</option>
                    <option >Qatar</option>
                </select>
            </div>
            <button type="reset" class="btn btn-white offset-sm-7">Cancel</button>
            <button type="submit" name="submit" class="btn btn-success">Save address</button>

        </form>
    </div>
    <script src="files/bootstrap.min.js"></script>
    <script src="files/jquery3.5.1.js"></script>




</body>

</html>